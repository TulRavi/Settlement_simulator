﻿namespace SettlementGame.Domain
{
    public class Class1
    {

    }
}
