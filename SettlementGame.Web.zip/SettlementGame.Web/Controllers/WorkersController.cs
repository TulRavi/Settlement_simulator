﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SettlementGame.Domain;

namespace SettlementGame.Web.Controllers
{
    [ApiController]//показывает принадлежность к ApiController
    [Route("api/workers")] //пишем адрес
    public class WorkersController : ControllerBase
    {
        private readonly DataWorld world;
        public WorkersController(DataWorld world) //DI-контейнер:видит, что нужен DataWorld,создаёт его(Singleton),
            //передаёт в контроллер - вместо new DataWorld().
        {
            this.world = world;
        }
        [HttpGet]
        public IActionResult GetWorkers()
        {
            return Ok(world.workersList);//возвращает JSON
        }
    }
}
